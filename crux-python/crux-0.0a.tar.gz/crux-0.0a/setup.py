#!/usr/bin/env python

from distutils.core import setup

setup(name='crux',
      version='0.0a',
      description='CRUX python module',
      author='Lucas Hazel',
      author_email='lucas@die.net.au',
      url='http://git.die.net.au/cgit/crux/tools/crux-python',
      packages=['crux'])
